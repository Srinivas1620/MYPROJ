// Simple Authentication System - Based on the proven direct approach
document.addEventListener('DOMContentLoaded', function() {
    console.log('Simple Auth System initialized');

    // Get form elements
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');

    // Add event listeners for form submissions
    if (loginForm) {
        console.log('Login form found, attaching handler');
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Login form submitted through event listener');
            handleLogin();
        });
    } else {
        console.warn('Login form not found!');
    }

    if (registerForm) {
        console.log('Register form found, attaching handler');
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Register form submitted through event listener');
            
            // Additional debug logs
            const emailInput = document.getElementById('register-email');
            console.log('Register form input value:', emailInput.value);
            console.log('Register form input type:', emailInput.type);
            
            // Ensure we're not doing any email validation
            handleRegister();
        });
    } else {
        console.warn('Register form not found!');
    }

    // Add logout handlers to any elements with logout class
    const logoutElements = document.querySelectorAll('.logout');
    logoutElements.forEach(element => {
        element.addEventListener('click', function(e) {
            e.preventDefault();
            handleLogout();
        });
    });

    // Check if user is logged in on page load
    checkAuthStatus();
});

// Handle login form submission
function handleLogin() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    if (!email || !password) {
        alert('Please enter both email and password');
        return;
    }
    
    console.log('Attempting login with:', email);
    
    // Create XHR object for login
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'http://localhost:5000/login', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    
    xhr.onload = function() {
        console.log('Login response status:', xhr.status);
        console.log('Login response text:', xhr.responseText);
        
        if (xhr.status >= 200 && xhr.status < 300) {
            try {
                const response = JSON.parse(xhr.responseText);
                localStorage.setItem('token', response.token);
                alert('Login successful!');
                updateUIForLoggedInUser();
                showsection('home');
            } catch (e) {
                console.error('Error parsing login response:', e);
                alert('Error processing login response');
            }
        } else {
            try {
                const response = JSON.parse(xhr.responseText);
                
                // Check for specific error cases with improved messaging
                if (response.error === 'User does not exist' && xhr.status === 401) {
                    alert('User does not exist. Please register first.');
                    // Redirect to the registration form
                    showsection('register');
                } else if (response.error === 'Invalid password' && xhr.status === 401) {
                    alert('Invalid password. Please try again.');
                } else {
                    alert(`Login failed: ${response.error || 'Unknown error'}`);
                }
            } catch (e) {
                console.error('Error parsing login response:', e);
                alert('Login failed: Server error');
            }
        }
    };
    
    xhr.onerror = function() {
        console.error('Login request failed');
        alert('Network error during login. Please check your connection.');
    };
    
    // Create payload and log for debugging
    const payload = {
        email: email,
        password: password
    };
    
    console.log('DEBUG - Sending login payload:', JSON.stringify(payload));
    
    // Send the login request
    xhr.send(JSON.stringify(payload));
}

// Handle register form submission
function handleRegister() {
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;
    
    console.log('DEBUG - Register function called with email/username:', email);
    
    if (!email || !password || !confirmPassword) {
        alert('Please fill out all fields');
        console.log('DEBUG - Registration aborted: empty fields');
        return;
    }
    
    if (password !== confirmPassword) {
        alert('Passwords do not match');
        console.log('DEBUG - Registration aborted: passwords do not match');
        return;
    }
    
    // Make sure we're not validating email format
    console.log('DEBUG - Registration proceeding with username/email:', email);
    
    console.log('Attempting registration with:', email);
    
    // Create XHR object for registration
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'http://localhost:5000/register', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    
    xhr.onload = function() {
        console.log('Registration response status:', xhr.status);
        console.log('Registration response text:', xhr.responseText);
        
        if (xhr.status >= 200 && xhr.status < 300) {
            alert('Registration successful! Please sign in.');
            showsection('signin');
        } else {
            try {
                const response = JSON.parse(xhr.responseText);
                console.log('Registration failed with error:', response.error);
                
                if (response.error && response.error.includes('already exists')) {
                    alert('This username/email is already taken. Please try another one.');
                } else {
                    alert(`Registration failed: ${response.error || 'Unknown error'}`);
                }
            } catch (e) {
                console.error('Error parsing registration response:', e);
                alert('Registration failed: Server error');
            }
        }
    };
    
    xhr.onerror = function() {
        console.error('Registration request failed');
        alert('Network error during registration. Please check your connection.');
    };
    
    // Create payload and log for debugging
    const payload = {
        email: email,
        password: password
    };
    
    console.log('DEBUG - Sending registration payload:', JSON.stringify(payload));
    console.log('Registration request headers:', xhr.getAllResponseHeaders());
    console.log('Registration request URL:', xhr.responseURL);
    console.log('Registration request method:', xhr.method);
    
    // Send the registration request
    xhr.send(JSON.stringify(payload));
}

// Check authentication status and update UI accordingly
function checkAuthStatus() {
    const token = localStorage.getItem('token');
    if (token) {
        console.log('User is logged in (token found)');
        updateUIForLoggedInUser(true);
    } else {
        console.log('User is not logged in (no token)');
        updateUIForLoggedInUser(false);
    }
}

// Update UI based on login status
function updateUIForLoggedInUser(isLoggedIn) {
    // Elements to show/hide based on auth status
    const authElements = document.querySelectorAll('.auth-only');
    const nonAuthElements = document.querySelectorAll('.non-auth-only');
    
    console.log('Updating UI elements for auth status:', isLoggedIn);
    console.log('Auth-only elements found:', authElements.length);
    console.log('Non-auth elements found:', nonAuthElements.length);
    
    if (isLoggedIn) {
        // User is logged in - show auth elements, hide non-auth elements
        authElements.forEach(el => el.style.display = '');
        nonAuthElements.forEach(el => el.style.display = 'none');
    } else {
        // User is logged out - hide auth elements, show non-auth elements
        authElements.forEach(el => el.style.display = 'none');
        nonAuthElements.forEach(el => el.style.display = '');
    }
    
    // Update cart display if needed
    if (typeof updateCart === 'function') {
        updateCart();
    }
}

// Handle logout
function handleLogout() {
    console.log('Logging out user');
    localStorage.removeItem('token');
    updateUIForLoggedInUser(false);
    alert('You have been logged out');
    showsection('home');
}

// Expose these functions globally for direct button access if needed
window.handleLogin = handleLogin;
window.handleRegister = handleRegister;
window.handleLogout = handleLogout;

// Add direct handlers to buttons as a fallback
window.addEventListener('load', function() {
    console.log('Adding direct button handlers as fallback');
    
    // Add click handlers to login button
    const loginButtons = document.querySelectorAll('#signin button');
    loginButtons.forEach(button => {
        console.log('Adding direct handler to login button');
        button.onclick = function(e) {
            e.preventDefault();
            console.log('Login button clicked directly');
            handleLogin();
            return false;
        };
    });
    
    // Add click handlers to register button
    const registerButtons = document.querySelectorAll('#register button');
    registerButtons.forEach(button => {
        console.log('Adding direct handler to register button');
        button.onclick = function(e) {
            e.preventDefault();
            console.log('Register button clicked directly');
            handleRegister();
            return false;
        };
    });
});
