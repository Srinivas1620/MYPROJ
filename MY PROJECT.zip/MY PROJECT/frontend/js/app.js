// DriveSure App Integration
const API_URL = 'http://localhost:5000';
let token = localStorage.getItem('token');
let cartItems = [];

// Check if user is logged in
function isLoggedIn() {
  return !!token;
}

// Update UI based on login status
function updateUI() {
  if (isLoggedIn()) {
    // Show logout option in UI
    const signinContent = document.getElementById('signin');
    if (signinContent) {
      signinContent.innerHTML = `
        <div class="bg-black sign-in d-flex flex-row justify-content-center">
          <div class="d-flex flex-column justify-content-start" style="text-align: center;padding:15px;background-color: #e01e30;border-radius:30px;height: 55vh;width:30vw;margin-top: 10vh;">
            <h1 class="text-white mb-5" style="font-weight: bold;">You are logged in!</h1>
            <button onclick="logout()" class="btn btn-light mb-3">Logout</button>
          </div>
        </div>
      `;
    }
  }
}

// Logout function
function logout() {
  localStorage.removeItem('token');
  token = null;
  cartItems = [];
  showsection('home');
  location.reload(); // Refresh the page
}

// Register user
async function registerUser(event) {
  event.preventDefault();
  console.log('Register form submitted');
  
  const email = document.getElementById('register-email').value;
  const password = document.getElementById('register-password').value;
  const confirmPassword = document.getElementById('register-confirm-password').value;

  console.log('Registration data:', { email, password: '*****' });

  if (password !== confirmPassword) {
    alert('Passwords do not match');
    return;
  }

  try {
    console.log('Sending registration request to:', `${API_URL}/register`);
    
    const response = await fetch(`${API_URL}/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
      mode: 'cors'
    });

    console.log('Registration response status:', response.status);
    
    const data = await response.json();
    console.log('Registration response data:', data);

    if (response.ok) {
      alert('Registration successful! Please sign in.');
      showsection('signin');
    } else {
      alert(`Registration failed: ${data.error || 'Unknown error'}`);
    }
  } catch (error) {
    console.error('Error during registration:', error);
    alert('An error occurred during registration. Please check console for details.');
  }
}

// Login user
async function loginUser(event) {
  event.preventDefault();
  console.log('Login form submitted');
  
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  console.log('Login data:', { email, password: '*****' });

  try {
    console.log('Sending login request to:', `${API_URL}/login`);
    
    const response = await fetch(`${API_URL}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
      mode: 'cors'
    });

    console.log('Login response status:', response.status);
    
    const data = await response.json();
    console.log('Login response data:', data);

    if (response.ok) {
      token = data.token;
      localStorage.setItem('token', token);
      updateUI();
      showsection('home');
      alert('Login successful!');
    } else {
      alert(`Login failed: ${data.error || 'Unknown error'}`);
    }
  } catch (error) {
    console.error('Error during login:', error);
    alert('An error occurred during login. Please check console for details.');
  }
}

// Fetch products
async function fetchProducts() {
  try {
    const response = await fetch(`${API_URL}/products`);
    const products = await response.json();
    return products;
  } catch (error) {
    console.error('Error fetching products:', error);
    return [];
  }
}

// Populate store items with "Add to Cart" functionality
async function setupStore() {
  const products = await fetchProducts();
  const storeSection = document.getElementById('store');
  
  // We're not replacing the whole store section as we want to keep the UI,
  // just add event listeners to the Add to Cart buttons
  
  // Find all "Add to Cart" buttons in the store section
  const addToCartButtons = storeSection.querySelectorAll('.home-dots');
  
  // Associate each button with its product
  addToCartButtons.forEach((button, index) => {
    if (index < products.length) {
      const product = products[index];
      
      // Add product ID as data attribute
      button.setAttribute('data-product-id', product.id);
      
      // Add click event listener
      button.addEventListener('click', () => addToCart(product.id));
    }
  });
}

// Add to cart function
async function addToCart(productId) {
  if (!isLoggedIn()) {
    alert('Please sign in to add items to your cart');
    showsection('signin');
    return;
  }

  try {
    const response = await fetch(`${API_URL}/cart/add`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ product_id: productId, quantity: 1 }),
    });

    if (response.ok) {
      alert('Item added to cart!');
      // Refresh cart when user views it
    } else {
      const data = await response.json();
      alert(`Failed to add item: ${data.error}`);
    }
  } catch (error) {
    console.error('Error adding to cart:', error);
    alert('An error occurred while adding to cart. Please try again.');
  }
}

// Fetch cart items
async function fetchCart() {
  if (!isLoggedIn()) {
    return { items: [], total_price: 0 };
  }

  try {
    const response = await fetch(`${API_URL}/cart`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (response.ok) {
      const cartData = await response.json();
      return cartData;
    } else {
      console.error('Failed to fetch cart');
      return { items: [], total_price: 0 };
    }
  } catch (error) {
    console.error('Error fetching cart:', error);
    return { items: [], total_price: 0 };
  }
}

// Display cart items
async function displayCart() {
  const cartSection = document.getElementById('cart');
  
  if (!isLoggedIn()) {
    cartSection.innerHTML = `
      <div class="bg-black cart-page">
        <div class="container">
          <h1 class="text-white text-center pt-5">Your Cart</h1>
          <div class="text-white text-center mt-5">
            <p>Please sign in to view your cart</p>
            <button onclick="showsection('signin')" class="btn btn-danger mt-3">Sign In</button>
          </div>
        </div>
      </div>
    `;
    return;
  }

  const cartData = await fetchCart();
  const { items, total_price } = cartData;

  if (items.length === 0) {
    cartSection.innerHTML = `
      <div class="bg-black cart-page">
        <div class="container">
          <h1 class="text-white text-center pt-5">Your Cart</h1>
          <div class="text-white text-center mt-5">
            <p>Your cart is empty</p>
            <button onclick="showsection('store')" class="btn btn-danger mt-3">Browse Services</button>
          </div>
        </div>
      </div>
    `;
    return;
  }

  let cartHTML = `
    <div class="bg-black cart-page">
      <div class="container">
        <h1 class="text-white text-center pt-5">Your Cart</h1>
        <div class="row mt-4">
  `;

  items.forEach(item => {
    cartHTML += `
      <div class="col-md-12 mb-4">
        <div class="card bg-dark text-white">
          <div class="row no-gutters">
            <div class="col-md-2">
              <img src="${item.image_url}" class="card-img" alt="${item.name}" style="height: 100%; object-fit: cover;">
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">${item.name}</h5>
                <p class="card-text">${item.description}</p>
                <p class="card-text">
                  <small class="text-muted">Quantity: ${item.quantity}</small>
                </p>
                <p class="card-text">Price: ₹${item.price}</p>
                <p class="card-text">Total: ₹${item.total_item_price}</p>
              </div>
            </div>
            <div class="col-md-2 d-flex align-items-center justify-content-center">
              <button class="btn btn-danger" onclick="removeFromCart(${item.id})">Remove</button>
            </div>
          </div>
        </div>
      </div>
    `;
  });

  cartHTML += `
        </div>
        <div class="row mt-3 mb-5">
          <div class="col-md-12">
            <div class="card bg-dark text-white">
              <div class="card-body text-right">
                <h4>Total Bill: ₹${total_price}</h4>
                <button class="btn btn-success mt-3">Proceed to Checkout</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  cartSection.innerHTML = cartHTML;
}

// Remove from cart
async function removeFromCart(itemId) {
  try {
    const response = await fetch(`${API_URL}/cart/remove/${itemId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (response.ok) {
      alert('Item removed from cart');
      displayCart(); // Refresh cart display
    } else {
      const data = await response.json();
      alert(`Failed to remove item: ${data.error}`);
    }
  } catch (error) {
    console.error('Error removing from cart:', error);
    alert('An error occurred while removing from cart. Please try again.');
  }
}

// Override the showsection function to update the cart display
const originalShowSection = window.showsection;
window.showsection = function(section) {
  originalShowSection(section);
  
  if (section === 'cart') {
    displayCart();
  }
};

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  console.log('DriveSure app initialized');
  
  // Update UI based on login status
  updateUI();
  
  // Setup store product functionality
  setupStore();
  
  // Add event listeners to the forms
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    console.log('Register form found, adding event listener');
    registerForm.addEventListener('submit', registerUser);
  } else {
    console.error('Register form not found!');
  }
  
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    console.log('Login form found, adding event listener');
    loginForm.addEventListener('submit', loginUser);
  } else {
    console.error('Login form not found!');
  }
  
  // Add additional listener to the buttons directly as a fallback
  const signInSubmitButton = document.querySelector('#signin button[type="submit"]');
  if (signInSubmitButton) {
    console.log('Sign in submit button found, adding click listener');
    signInSubmitButton.addEventListener('click', function(e) {
      const form = document.getElementById('login-form');
      if (form) form.dispatchEvent(new Event('submit'));
    });
  }
  
  const registerSubmitButton = document.querySelector('#register button[type="submit"]');
  if (registerSubmitButton) {
    console.log('Register submit button found, adding click listener');
    registerSubmitButton.addEventListener('click', function(e) {
      const form = document.getElementById('register-form');
      if (form) form.dispatchEvent(new Event('submit'));
    });
  }
});
