from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash

# Initialize Flask app
app = Flask(__name__)
# Enable CORS for all routes with more explicit settings
CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)  

# JWT Configuration
app.config['JWT_SECRET_KEY'] = 'drivesure-secret-key'  # Change this in production!
jwt = JWTManager(app)

# Initialize database
def init_db():
    # Create database file if it doesn't exist
    if not os.path.exists('drivesure.db'):
        conn = sqlite3.connect('drivesure.db')
        cursor = conn.cursor()
        
        # Create users table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
        ''')
        
        # Create products table and insert products
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            description TEXT,
            image_url TEXT
        )
        ''')
        
        # Insert products (from the frontend)
        products = [
            ('Vehicle Servicing', 4000, 'Our services include oil changes, tire rotations, and brake inspections. We also offer a variety of other services to keep your vehicle running smoothly.', 'img/goldengine.jpg'),
            ('Vehicle Checkup', 1500, 'Ensure your vehicle\'s peak performance with our comprehensive and affordable DriveSure checkup service.', 'img/full.jpg'),
            ('Yearly Subscription', 16000, 'Access to everything DriveSure has to offer.', 'img/fserv.jpeg')
        ]
        
        cursor.executemany('INSERT INTO products (name, price, description, image_url) VALUES (?, ?, ?, ?)', products)
        
        # Create cart table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS cart_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (product_id) REFERENCES products (id)
        )
        ''')
        
        conn.commit()
        conn.close()

# Initialize database on startup
init_db()

# Helper function to get database connection
def get_db_connection():
    conn = sqlite3.connect('drivesure.db')
    conn.row_factory = sqlite3.Row  # This enables column access by name
    return conn

# User Registration
@app.route('/register', methods=['POST'])
def register():
    print('Registration request received')
    data = request.get_json()
    print('Registration data:', data)
    
    if not data or not data.get('email') or not data.get('password'):
        print('Missing username/email or password')
        return jsonify({'error': 'Missing username/email or password'}), 400
    
    # Get the username/email from the request (using 'email' parameter for compatibility)
    username_or_email = data.get('email')
    password = generate_password_hash(data.get('password'))
    
    print(f'DEBUG - Registration attempt with username/email: "{username_or_email}"')
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # First check if username/email already exists
    existing_user = cursor.execute('SELECT * FROM users WHERE email = ?', (username_or_email,)).fetchone()
    if existing_user:
        print(f'DEBUG - Registration failed: Username/email "{username_or_email}" already exists')
        conn.close()
        return jsonify({'error': 'Username/email already exists'}), 400
    
    # Proceed with registration
    try:
        cursor.execute('INSERT INTO users (email, password) VALUES (?, ?)', (username_or_email, password))
        conn.commit()
        new_user_id = cursor.lastrowid
        print(f'DEBUG - User registered successfully: ID={new_user_id}, Username/Email="{username_or_email}"')
        conn.close()
        return jsonify({'message': 'User registered successfully'}), 201
    except sqlite3.IntegrityError as e:
        print(f'DEBUG - Registration error (integrity): {e}')
        conn.close()
        return jsonify({'error': 'Username/email already exists'}), 400
    except Exception as e:
        print(f'DEBUG - Unexpected registration error: {e}')
        conn.close()
        return jsonify({'error': str(e)}), 500

# User Login
@app.route('/login', methods=['POST'])
def login():
    print('Login request received')
    data = request.get_json()
    print('Login data:', data)
    
    if not data or not data.get('email') or not data.get('password'):
        print('Missing username/email or password')
        return jsonify({'error': 'Missing username/email or password'}), 400
    
    # Get username/email value from request
    username_or_email = data.get('email')  # We keep the param name as 'email' for compatibility
    password = data.get('password')
    
    print(f'DEBUG - Login attempt with username/email: "{username_or_email}"')
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Debug: Print all users in the database
    all_users = cursor.execute('SELECT id, email FROM users').fetchall()
    print('DEBUG - All users in database:', [(u['id'], u['email']) for u in all_users])
    
    # Try to find the user - exact match on the email field (which can contain username or email)
    user = cursor.execute('SELECT * FROM users WHERE email = ?', (username_or_email,)).fetchone()
    
    # Debug: Print user lookup result
    if user:
        print(f'DEBUG - User found: ID={user["id"]}, Email/Username="{user["email"]}"')
    else:
        print(f'DEBUG - User not found: "{username_or_email}"')
        conn.close()
        return jsonify({'error': 'User does not exist'}), 401
    
    # Verify password
    if not check_password_hash(user['password'], password):
        print(f'DEBUG - Invalid password for user: "{username_or_email}"')
        conn.close()
        return jsonify({'error': 'Invalid password'}), 401
    
    # Create access token
    access_token = create_access_token(identity=user['id'])
    print(f'DEBUG - Login successful: ID={user["id"]}, Email/Username="{user["email"]}"')
    conn.close()
    return jsonify({'token': access_token, 'username': user['email']}), 200

# Get Products
@app.route('/products', methods=['GET'])
def get_products():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    products = cursor.execute('SELECT * FROM products').fetchall()
    conn.close()
    
    # Convert to list of dicts
    product_list = []
    for product in products:
        product_list.append({
            'id': product['id'],
            'name': product['name'],
            'price': product['price'],
            'description': product['description'],
            'image_url': product['image_url']
        })
    
    return jsonify(product_list), 200

# Add to Cart
@app.route('/cart/add', methods=['POST'])
@jwt_required()
def add_to_cart():
    current_user_id = get_jwt_identity()
    data = request.get_json()
    
    if not data or not data.get('product_id'):
        return jsonify({'error': 'Product ID required'}), 400
    
    product_id = data.get('product_id')
    quantity = data.get('quantity', 1)
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Check if product exists
    product = cursor.execute('SELECT * FROM products WHERE id = ?', (product_id,)).fetchone()
    if not product:
        conn.close()
        return jsonify({'error': 'Product not found'}), 404
    
    # Check if item already in cart
    cart_item = cursor.execute(
        'SELECT * FROM cart_items WHERE user_id = ? AND product_id = ?', 
        (current_user_id, product_id)
    ).fetchone()
    
    if cart_item:
        # Update quantity
        cursor.execute(
            'UPDATE cart_items SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?',
            (quantity, current_user_id, product_id)
        )
    else:
        # Add new item
        cursor.execute(
            'INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)',
            (current_user_id, product_id, quantity)
        )
    
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Item added to cart'}), 201

# Get Cart Items
@app.route('/cart', methods=['GET'])
@jwt_required()
def get_cart():
    current_user_id = get_jwt_identity()
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Join cart_items with products to get product details
    cart_items = cursor.execute('''
        SELECT c.id, c.quantity, p.id as product_id, p.name, p.price, p.description, p.image_url
        FROM cart_items c
        JOIN products p ON c.product_id = p.id
        WHERE c.user_id = ?
    ''', (current_user_id,)).fetchall()
    
    conn.close()
    
    # Convert to list of dicts
    items = []
    total_price = 0
    
    for item in cart_items:
        item_price = item['price'] * item['quantity']
        total_price += item_price
        
        items.append({
            'id': item['id'],
            'product_id': item['product_id'],
            'name': item['name'],
            'price': item['price'],
            'quantity': item['quantity'],
            'total_item_price': item_price,
            'description': item['description'],
            'image_url': item['image_url']
        })
    
    return jsonify({
        'items': items,
        'total_price': total_price
    }), 200

# Remove from Cart
@app.route('/cart/remove/<int:item_id>', methods=['DELETE'])
@jwt_required()
def remove_from_cart(item_id):
    current_user_id = get_jwt_identity()
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Check if item exists and belongs to the user
    item = cursor.execute(
        'SELECT * FROM cart_items WHERE id = ? AND user_id = ?', 
        (item_id, current_user_id)
    ).fetchone()
    
    if not item:
        conn.close()
        return jsonify({'error': 'Item not found in cart'}), 404
    
    # Delete the item
    cursor.execute('DELETE FROM cart_items WHERE id = ?', (item_id,))
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Item removed from cart'}), 200

# Debugging endpoint to get all users (for testing)
@app.route('/all-users', methods=['GET'])
def get_all_users():
    print('DEBUG - Request to get all users received')
    conn = get_db_connection()
    cursor = conn.cursor()
    users = cursor.execute('SELECT id, email FROM users').fetchall()
    print('DEBUG - Found', len(users), 'users in database')
    conn.close()
    return jsonify([dict(user) for user in users])



# Run the application
if __name__ == '__main__':
    init_db()
    print('Starting DriveSure backend server on port 5000')
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
